package com.carefirst.fep.filedrop;

import java.io.File;
import java.io.FileFilter;
import org.testng.annotations.Test;

import com.carefirst.fep.filedrop.BridgeSender;
import com.carefirst.fep.filedrop.Constants;;

public class TestSenderMQ_E2E implements FileFilter {

	@Test
	public void test() {
		File dir = new File("C:\\Users\\aac8154\\Desktop\\temp\\");
		File[] files = dir.listFiles(new TestSenderMQ_E2E());
		if (files != null) {
			for (File file : files) {
				String srcDir = "C:\\Users\\aac8154\\Desktop\\temp\\" + file.getName();

				if (file.getName().matches("PM")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayPMRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				}
			}
		} else {
			System.out.println("No Subdirectory Found.");
		}
	}

	public boolean accept(File file) {
		return file.isDirectory();
	}

}
