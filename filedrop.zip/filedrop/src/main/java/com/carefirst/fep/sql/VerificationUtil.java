package com.carefirst.fep.sql;
/**
 * @author Uthaya Kumar Ravichandran
 * Date: 01/15/2019
 * Purpose: Check the dcn in request, response, error tables and display the results in report
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class VerificationUtil {

	private static Connection conn;
	String[] dcnNoRq = new String[250], dcnNoRs = new String[250], dcnErr = new String[250],
			dcnSuccess = new String[250], err = new String[250], dcnCncErr = new String[250];
	int cntDcnNoRq = 0, cntDcnErr = 0, cntDcnNoRs = 0, cntDcnSuccess = 0, cntErr = 0, cntDcn = 0;//, cntCncErr = 0;

	private Properties prop;

	public void loadProperties(String env) {
		prop = new Properties();

		InputStream in = this.getClass().getClassLoader().getResourceAsStream(env + ".properties");
		try {
			prop.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getValue(String str) {
		return prop.getProperty(str);
	}

	protected Connection connect() {
		/*
		 * This is to connect to the Database using the oracle driver, connection string,
		 * user credentials and encrypted password
		 */
		String dPassword = null;
		String username = getValue("username");
		String encryptedPassword = getValue("encryptedPassword");
		ProtectedPwdFile eCypher = new ProtectedPwdFile();

		try {
			dPassword = eCypher.decrypt(encryptedPassword);
		} catch (GeneralSecurityException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String environment = getValue("environment");
			
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(environment, username, dPassword);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	public boolean VerifyClaims(ExtentTest logger, String dcnFile, String rspnsQuery, String workspace) throws IOException, SQLException {

		String dcn = "", qvReqQuery, qvResQuery, qvErrQuery, component;

		Connection e = connect();
		cleanDir(workspace);
		
		cntDcnNoRq = 0;
		cntDcnErr = 0;
		cntDcnNoRs = 0;
		cntDcnSuccess = 0;
		cntErr = 0;
		//cntCncErr = 0;
		cntDcn = 0;

		System.out.println("Verifying Claims in the file " + dcnFile);

		BufferedReader readDCNFile = new BufferedReader(new FileReader(dcnFile));

		qvReqQuery = "qvReqFEPOCQuery";
		qvResQuery = rspnsQuery ;//"qvResFEPOCQuery";
		component = "FEPOCRequest";
		qvErrQuery = "qvErrQuery";

		while (((dcn = readDCNFile.readLine()) != null)) {
			printDataInLog(e, dcn, qvReqQuery, qvResQuery, qvErrQuery, component, workspace);
			cntDcn++;
		}
		readDCNFile.close();
		updateExtentReport(logger);

		e.close();
		
		if (cntErr>0 || cntDcnNoRq>0 || cntDcnNoRs > 0)
			return false;
		else
			return true;

	}


	private void printDataInLog(Connection e, String dcn, String qvReqQuery, String qvResQuery, String qvErrQuery,
			String component, String workspace) throws SQLException {
		String reqQuery, resQuery, errQuery;
		PreparedStatement reqPS, resPS, errPS;
		ResultSet reqRS, resRS, errRS;

		dcn = dcn.replaceAll(" ", "");

		// Pricing Request Queries
		reqQuery = getValue(qvReqQuery);
		reqPS = e.prepareStatement(reqQuery);
		reqPS.setString(1, dcn);
		reqRS = reqPS.executeQuery();

		// Pricing Response Queries
		resQuery = getValue(qvResQuery);
		resPS = e.prepareStatement(resQuery);
		resPS.setString(1, dcn);
		resRS = resPS.executeQuery();

		// Error Queries
		errQuery = getValue(qvErrQuery);
		errPS = e.prepareStatement(errQuery);
		errPS.setString(1, dcn);
		errRS = errPS.executeQuery();

		if (reqRS.next() == true)
			errorVerification(resRS, errRS, dcn, component, workspace);
		else
			dcnNoRq[cntDcnNoRq++] = dcn;

		reqRS.close();
		reqPS.close();
		resRS.close();
		resPS.close();
		errRS.close();
		errPS.close();
	}

	private void errorVerification(ResultSet resRS, ResultSet errRS, String dcn, String component, String workspace) throws SQLException {
		if (resRS.next() == false) {

			if (errRS.next() == true) {
				dcnErr[cntErr] = dcn;
				err[cntErr++] = errRS.getString(1);
				writeErrorInFile(workspace, dcn, err[cntErr-1]);
			} else
				dcnNoRs[cntDcnNoRs++] = dcn;

		} else
			dcnSuccess[cntDcnSuccess++] = dcn;
	}
	

	private void cleanDir(String workspace) {
		/*
		 * Remove existing files inside the error directory
		 */
		File dir = new File(getValue(workspace) + "/Error");

		if(!dir.exists())
			dir.mkdir();
		
		for(File file: dir.listFiles()) 
		    if (!file.isDirectory()) 
		        file.delete();
	}
	
	private void writeErrorInFile(String workspace, String dcn, String error) {	
		/*
		 * Create a file with dcn as the name of the file inside error directory, enters the error text retrieved from DB and saves the file
		 */
		String fileName = getValue(workspace) + "/Error/" + dcn + ".txt";
		File errFile = new File(fileName);
		try {
			errFile.createNewFile();
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
			bw.write(error);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
/*
 * Below methods are for updating the error report
 */
	private void updateExtentReport(ExtentTest logger) {
		String reportContent = "<table style=\"width:50%\"><col width=\"50%\"><col width=\"10%\"><col width=\"20%\">";
		reportContent = reportContent + "<tr><td><b>Claims successfully loaded in DB : </b> </td><td>" + cntDcnSuccess
				+ "</td><td><span class='test-status label right outline capitalize pass'>PASS</span></td></tr>";
		
		reportContent = updateExtntRprtStatus(cntDcnNoRq, "Claims not available in Request  :", reportContent);
		reportContent = updateExtntRprtStatus(cntDcnNoRs, "Claims not available in Response :", reportContent);
		//reportContent = updateExtntRprtStatus(cntCncErr, "Claims not loaded due to connectivity Error :", reportContent);
		reportContent = updateExtntRprtStatus(cntErr, "Claims not loaded due to Technical Error :", reportContent);
				
		reportContent = reportContent + "<tr><td><b>Total number of claims submitted : </b> </td><td>" + cntDcn
				+ "</td><td><span class='test-status label right outline capitalize pass'>PASS</span></td></tr>";
		reportContent = reportContent + "</table>";

		logger.log(LogStatus.INFO, reportContent);
		System.out.println(reportContent);

		//updateExtntRprtWithDCN(logger, cntCncErr, "Connectivity Errored DCNs : ", dcnCncErr, LogStatus.FAIL);
		updateExtntRprtWithDCN(logger, cntErr, "Techinically Errored DCNs : ", dcnErr, LogStatus.FAIL);
		updateExtntRprtWithDCN(logger, cntDcnNoRq, "DCNs Not loaded in Request : ", dcnNoRq, LogStatus.FAIL);
		updateExtntRprtWithDCN(logger, cntDcnNoRs, "DCNs Not loaded in Response : " , dcnNoRs, LogStatus.FAIL);
		updateExtntRprtWithDCN(logger, cntDcnSuccess, "DCNs successfully loaded in db : " , dcnSuccess, LogStatus.PASS);
		

		if (cntErr > 2)
			cntErr = 2;
		reportContent = "Technical Errors: ";
		for (int i = 0; i < cntErr; i++)
			reportContent = reportContent + "<br>----------------------------<br>" + err[i].replace(")", ")<br>");
		if (cntErr > 0)
			logger.log(LogStatus.INFO, reportContent);

		System.out.println(reportContent);
	}

	private void updateExtntRprtWithDCN(ExtentTest logger, int count, String msg, String[] array, LogStatus status) {
		String reportContent = msg + array[0];
		for (int i = 1; i < count; i++)
			reportContent = reportContent + ", " + array[i];
		if (count > 0)
			logger.log(status, reportContent);
		System.out.println(reportContent);
	}

	private String updateExtntRprtStatus(int dataCount, String msg, String reportContent) {
		if (dataCount > 0)
			return reportContent + "<tr><td><b>" + msg + " </b> </td><td>" + dataCount
					+ "</td><td><span class='test-status label right outline capitalize fail'>FAIL</span></td></tr>";
		else
			return reportContent + "<tr><td><b>" + msg + " </b> </td><td>" + dataCount
					+ "</td><td><span class='test-status label right outline capitalize pass'>PASS</span></td></tr>";
	}

}
