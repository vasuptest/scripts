package com.carefirst.fep.on.demand.filedrop;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.filedrop.BridgeSender;
import com.carefirst.fep.filedrop.Constants;
import com.carefirst.fep.filedrop.FileDropUtil;
//import com.carefirst.fep.filedrop.UnZip;

public class Pav_ClaimSubmission extends FileDropUtil implements FileFilter {

	// public static String loadTyp = System.getenv("SELECT LOAD TYPE");
	public static String env = "sit";//System.getenv("ENVIRONMENT").toLowerCase();

	@BeforeClass
	public void load() throws IOException {
		loadProperties();
	}

	@Test(enabled = true)
	public void TC001_OnDemandFileDrop() {

		//String folderName = getValue("");// me folder path
		File dir = new File("E://Automation//pav//Claimdrop");
		File[] files = dir.listFiles();
		if (files != null) {
			for (File file : files) {
				String srcDir = file.getName();

				BridgeSender in = new BridgeSender(env, Constants.POST_ADJ_APP, "jms/FepocReplyToQueue");

				in.sendFromDir(srcDir);
				System.out.println(srcDir);
			}
		}

	
	}

	public boolean accept(File file) {
		return file.isDirectory();
	}

}
