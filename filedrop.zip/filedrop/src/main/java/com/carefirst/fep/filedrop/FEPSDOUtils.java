package com.carefirst.fep.filedrop;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import commonj.sdo.helper.HelperContext;
import commonj.sdo.helper.XMLDocument;

public class FEPSDOUtils {
	public final static String	CLAIM_CONTEXT		= "http://www.carefirst.com/FEPClaimMessage";
//
//	/**
//	 * Loads XML Schema and defines SDO XSDHelper for it in the given
//	 * HelperContext
//	 * @param scope
//	 * @param fileName
//	 */
	public static void loadTypesFromXMLSchemaFile(HelperContext scope, String fileName) {
//	    XSDHelper xsdHelper = scope.getXSDHelper();
//
//	    InputStream is = null;
//	    try {
//
//	        URL url = FEPSDOUtils.class.getClassLoader().getResource(fileName);
//
//	        is = url.openStream();
//	        xsdHelper.define(is, url.toString());
//
//	     } catch (Exception e) {
//
//	     } finally {
//	       try {
//	    	   if (is!=null)
//	    		   is.close();
//	       } catch (Exception e) {
//
//	       }
//	   }
	}
//
//	/**
//	 * Creates and loads a SDO XML document from a String
//	 * @param scope
//	 * @param xmlDoc
//	 * @return
//	 */
	public static XMLDocument getXMLDocumentFromString(HelperContext scope, String xmlDoc) throws IOException {
	    InputStream is = new ByteArrayInputStream(xmlDoc.getBytes());
		return	scope.getXMLHelper().load(is);
    }
//
//	public static String getStringFromDataObject(HelperContext scope, DataObject dataObject) {
//
//		return scope.getXMLHelper().save(dataObject, CLAIM_CONTEXT, "claimContext");
//	}
//
//	public static BigDecimal getBigDecimal(DataObject dataObject, String elementPath, BigDecimal defaultValueWhenNull)
//	{
//		if(dataObject==null)
//			return defaultValueWhenNull;
//
//		Object o = dataObject.get(elementPath);
//		if(o==null)
//		{
//			return defaultValueWhenNull;
//		}
//		else
//		{
//			if(o instanceof BigDecimal)
//			{
//				return (BigDecimal)o;
//			}
//
//			String value = (String)o;
//
//			if("".equals(value))
//			{
//				return defaultValueWhenNull;
//			}
//			return new BigDecimal(value);
//		}
//	}
//
//	public static Integer getInteger(DataObject dataObject, String elementPath)
//	{
//		if(dataObject==null || elementPath == null)
//			return null;
//
//		String value = dataObject.getString(elementPath);
//		if(value != null && value.trim().length() != 0){
//			//This is to avoid a numberformatexception. Some times, we get
//			//a value like 5.0, that needs to be converted.
//			BigDecimal tmpDecimal = new BigDecimal(value);
//			return Integer.valueOf(tmpDecimal.intValue());
//		}
//		return null;
//
//	}
//
//
//	public static DataObject getOrCreateChildDO(DataObject parentDO, String childDOName)
//	{
//		DataObject childDO = parentDO.getDataObject(childDOName);
//		if (childDO==null)
//		{
//			childDO = createDO(parentDO, childDOName);
//		}
//		return childDO;
//	}
//
//	public static DataObject createDO(DataObject parentDO, String childDOName)
//	{
//		return parentDO.createDataObject(childDOName);
//	}

}
