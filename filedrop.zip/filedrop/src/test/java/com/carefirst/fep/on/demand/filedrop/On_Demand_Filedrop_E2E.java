package com.carefirst.fep.on.demand.filedrop;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.filedrop.BridgeSender;
import com.carefirst.fep.filedrop.Constants;
import com.carefirst.fep.filedrop.FileDropUtil;
import com.carefirst.fep.filedrop.UnZip;

public class On_Demand_Filedrop_E2E extends FileDropUtil implements FileFilter {
	
	public static String component = System.getenv("COMPONENT");

	@BeforeClass
	public void load() throws IOException {
		loadProperties();
		// createNewDCNFile(getValue("claimSmokeDCNFile"));
	}
	
	@Test(enabled = true) // 
	public void TC001_FileDrop() {
		
		//Unzips the input provider file by the user.
		String inputFolder = getValue("inputFiles");
		String outputFolder = getValue("outputFiles");
		
		UnZip unZip = new UnZip();
		unZip.unZipIt(inputFolder, outputFolder);
		
		File dir = new File(outputFolder);
		File[] files = dir.listFiles();
		if (files != null) {
			for (File file : files) {
				String srcDir = outputFolder + file.getName();
				if (component.equals("CGWForwarder")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/GatewayRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (component.equals("UCMT-CB")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayCambiaRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (component.equals("UCMT-NC")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayNCRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (component.equals("UCMT-PM")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayPMRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (component.equals("UCMT-WM")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayWMRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (component.equals("UCMT-NE")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayNERequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (component.equals("LPP-CF")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (component.equals("LPP-CB")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocCambiaLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (component.equals("LPP-NC")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocNCLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (component.equals("LPP-PM")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocPMLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (component.equals("LPP-WM")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocWMLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (component.equals("LPP-NE")) {
					BridgeSender in = new BridgeSender(Constants.E2E_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocNELppRequestQueue");
					in.sendFromDir(srcDir);
				}
			}
		} else {
			System.out.println("No Subdirectory Found.");
		}
	}

	public boolean accept(File file) {
		return file.isDirectory();
	}

}
