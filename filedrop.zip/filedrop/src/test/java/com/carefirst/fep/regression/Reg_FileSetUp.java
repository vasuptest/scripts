package com.carefirst.fep.regression;
/**
 * @author Uthaya Kumar Ravichandran
 * Date: 03/29/2019
 * Purpose: To create the folders needed for regression Testing
 */
import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.sql.DB_VerificationUtil;

public class Reg_FileSetUp extends DB_VerificationUtil {
	String env = System.getProperty("env");

	@BeforeClass
	public void load() {
		loadProperties(env);
	}

	@Test
	public void setUp() {
		createFolders(getValue("reg_DB_Mdcl_fldr"));
		createFolders(getValue("reg_EDI_Mdcl_fldr"));

		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/CAREFIRST");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/CAMBIA");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/NORTHCAROLINA");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/PREMERA");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/WELLMARK");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/NEBRASKA");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/CAREFIRST-LPP");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/CAMBIA-LPP");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/NORTHCAROLINA-LPP");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/PREMERA-LPP");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/WELLMARK-LPP");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/NEBRASKA-LPP");
		createFolders(getValue("reg_EDI_Mdcl_fldr") + "/NotInDB");


		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAREFIRST" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAMBIA" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NORTHCAROLINA" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/PREMERA" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/WELLMARK" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NEBRASKA" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAREFIRST-LPP" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAMBIA-LPP" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NORTHCAROLINA-LPP" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/PREMERA-LPP" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/WELLMARK-LPP" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NEBRASKA-LPP" + getValue("oldDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NotInDB" + getValue("oldDBFldrNm"));


		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAREFIRST"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAMBIA"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NORTHCAROLINA"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/PREMERA"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/WELLMARK"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NEBRASKA"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAREFIRST-LPP"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/CAMBIA-LPP"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NORTHCAROLINA-LPP"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/PREMERA-LPP"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/WELLMARK-LPP"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NEBRASKA-LPP"  + getValue("newDBFldrNm"));
		createFolders(getValue("reg_DB_Mdcl_fldr") + "/NotInDB"  + getValue("newDBFldrNm"));


		createParentFolders(getValue("reg_fl_old_DCN"));
		createParentFolders(getValue("MedRtrvFilesRprt"));
		createParentFolders(getValue("reg_rtrvQry_File"));
		
		createSQLFile(getValue("reg_rtrvQry_File"));
	}

	
	public void createFolders(String filePath) {
		File files = new File(filePath);
		if (!files.exists())
			files.mkdirs();

		System.out.println("All folders are created in following path: " + filePath);
	}

	public void createParentFolders(String filePath) {
		File files = new File(filePath).getParentFile();
		if (!files.exists())
			files.mkdirs();

		System.out.println("All folders are created in following path: " + filePath);
	}

	public void createSQLFile(String path) {
		String tempData = "SELECT c.TOT_CLM_CHRGS, c.CLM_TYP, c.OVERL_FRST_SERVC_DT, c.OVERL_LAST_SERVC_DT, c.PATN_DOB, c.PATN_FRST_NM, c.PATN_GNDR_CD, c.PATN_LAST_NM, c.PLAN_CD, c.SUBR_ID, c.RNDR_PROV_ID FROM FEPL_CLAIM.CLM C WHERE  c.dcn = ? ORDER BY c.TOT_CLM_CHRGS, c.CLM_TYP, c.OVERL_FRST_SERVC_DT, c.OVERL_LAST_SERVC_DT, c.PATN_DOB, c.PATN_FRST_NM, c.PATN_GNDR_CD, c.PATN_LAST_NM, c.PLAN_CD, c.SUBR_ID, c.RNDR_PROV_ID DESC\n" + 
				"SELECT ERR.CLM_ERR_CD FROM FEPL_CLAIM.CLM_EDIT_ERR ERR WHERE  ERR.dcn = ? ORDER BY ERR.CLM_ERR_CD DESC\n" + 
				"SELECT CV.BILLG_PROV_ID FROM FEPL_CLAIM.CLM_VERS CV WHERE  CV.dcn = ? ORDER BY CV.BILLG_PROV_ID DESC\n" + 
				"SELECT CD.PL_OF_SERVC_CD FROM FEPL_CLAIM.CLM_DENTL CD, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = CD.CLM_VERS_ID AND cV.dcn = ? ORDER BY CD.PL_OF_SERVC_CD DESC\n" + 
				"SELECT DG.DG_CD FROM FEPL_CLAIM.CLM_DG_CD DG, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = DG.CLM_VERS_ID AND cV.dcn = ? ORDER BY DG.DG_CD DESC\n" + 
				"SELECT INST.RNDR_PROV_ADDR_LINE_1, INST.FAC_TYP_CD, INST.clm_freq_cd  FROM FEPL_CLAIM.CLM_INSTL INST, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = INST.CLM_VERS_ID AND cV.dcn = ? ORDER BY INST.RNDR_PROV_ADDR_LINE_1, INST.FAC_TYP_CD, INST.clm_freq_cd   DESC\n" + 
				"SELECT LN.PRCR_ALLWD_AMT_LINE, 	LN.PRCG_LINE_NBR, 	LN.LINE_CMT, 	LN.SERVC_UNIT_CNT, 	LN.PROC_MODR_1, 	LN.PROC_MODR_2, 	LN.PROC_MODR_3, 	LN.PROC_MODR_4, 	LN.PROC_CD, 	LN.SERVC_LINE_REVN_CD, 	LN.UNIT_OR_MEASMT_CD  FROM FEPL_CLAIM.CLM_LINE LN, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = LN.CLM_VERS_ID AND cV.dcn = ? ORDER BY LN.PRCR_ALLWD_AMT_LINE, 	LN.PRCG_LINE_NBR, 	LN.LINE_CMT, 	LN.SERVC_UNIT_CNT, 	LN.PROC_MODR_1, 	LN.PROC_MODR_2, 	LN.PROC_MODR_3, 	LN.PROC_MODR_4, 	LN.PROC_CD, 	LN.SERVC_LINE_REVN_CD, DESC\n" + 
				"SELECT LN_PROF.PL_OF_SERVC_CD FROM FEPL_CLAIM.CLM_LINE_PROF_DATA LN_PROF, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = LN_PROF.CLM_VERS_ID AND cV.dcn = ? ORDER BY LN_PROF.PL_OF_SERVC_CD DESC \n" + 
				"SELECT LN_SUP_DT.EDIT_OVERR_CD_1, 	LN_SUP_DT.EDIT_OVERR_CD_2, 	LN_SUP_DT.EDIT_OVERR_CD_3, 	LN_SUP_DT.EDIT_OVERR_CD_4, 	LN_SUP_DT.EDIT_OVERR_CD_5, 	LN_SUP_DT.EOB_REMK_CD_1, 	LN_SUP_DT.EOB_REMK_CD_2, 	LN_SUP_DT.EOB_REMK_CD_3, 	LN_SUP_DT.EOB_REMK_CD_4, 	LN_SUP_DT.OC_AUTO_RESLN_CD, 	LN_SUP_DT.OTH_PAYR_AMT_PAID_LINE, 	LN_SUP_DT.SERVC_ACCUM_INDC FROM FEPL_CLAIM.CLM_LINE_SUPPL_DATA LN_SUP_DT, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = LN_SUP_DT.CLM_VERS_ID AND cV.dcn = ? ORDER BY LN_SUP_DT.EDIT_OVERR_CD_1, 	LN_SUP_DT.EDIT_OVERR_CD_2, 	LN_SUP_DT.EDIT_OVERR_CD_3, 	LN_SUP_DT.EDIT_OVERR_CD_4, 	LN_SUP_DT.EDIT_OVERR_CD_5, 	LN_SUP_DT.EOB_REMK_CD_1, 	LN_SUP_DT.EOB_REMK_CD_2, 	LN_SUP_DT.EOB_REMK_CD_3, 	LN_SUP_DT.EOB_REMK_CD_4, 	LN_SUP_DT.OC_AUTO_RESLN_CD, 	LN_SUP_DT.OTH_PAYR_AMT_PAID_LINE, 	LN_SUP_DT.SERVC_ACCUM_INDC DESC\n" + 
				"SELECT LN_DNTL.TTH_CD_1, 	LN_DNTL.TTH_CD_2, 	LN_DNTL.TTH_CD_3, 	LN_DNTL.TTH_CD_4 FROM FEPL_CLAIM.CLM_LINE_DENTL LN_DNTL, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = LN_DNTL.CLM_VERS_ID AND cV.dcn = ? ORDER BY LN_DNTL.TTH_CD_1, 	LN_DNTL.TTH_CD_2, 	LN_DNTL.TTH_CD_3, 	LN_DNTL.TTH_CD_4  DESC\n" + 
				"SELECT LN_NDC.NDC FROM FEPL_CLAIM.CLM_LINE_NDC LN_NDC, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = LN_NDC.CLM_VERS_ID AND cV.dcn = ? ORDER BY LN_NDC.NDC DESC\n" + 
				"SELECT SUPPL.DIRN_OF_PAYMT, SUPPL.RTNG_DEST FROM FEPL_CLAIM.CLM_OC_SUPPL_DATA SUPPL, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = SUPPL.CLM_VERS_ID AND cV.dcn = ? ORDER BY SUPPL.DIRN_OF_PAYMT, SUPPL.RTNG_DEST DESC\n" + 
				"SELECT OTH_PYR.OTH_PAYR_ALLWD_AMT FROM FEPL_CLAIM.CLM_OTH_PAYR_DATA OTH_PYR, FEPL_CLAIM.clm_vers cv  WHERE CV.CLM_VERS_ID = OTH_PYR.CLM_VERS_ID AND cV.dcn = ? ORDER BY OTH_PYR.OTH_PAYR_ALLWD_AMT DESC\n" + 
				"SELECT PAM_MAX_ALLWD FROM FEPL_CLAIM.CLMCHK_CUR_LINE_LVL_DATA LN_LVL, FEPL_CLAIM.CLMCHK_CLM_LVL_DATA CLM_LVL WHERE CLM_LVL.CLMCHK_CLM_LVL_DATA_ID = LN_LVL.CLMCHK_CLM_LVL_DATA_ID AND CLM_LVL.dcn = ? ORDER BY PAM_MAX_ALLWD DESC\n" + 
				"SELECT MSG.DFRRED_REAS_CD_1, 	MSG.DFRRED_REAS_CD_2, 	MSG.DFRRED_REAS_CD_3, 	MSG.DFRRED_REAS_CD_4, 	MSG.DFRRED_REAS_CD_5, 	MSG.RNDR_PROV_ZIP FROM FEPL_CLAIM.CLM_MSG_TRANS MSG WHERE  MSG.dcn = ? ORDER BY MSG.DFRRED_REAS_CD_1, 	MSG.DFRRED_REAS_CD_2, 	MSG.DFRRED_REAS_CD_3, 	MSG.DFRRED_REAS_CD_4, 	MSG.DFRRED_REAS_CD_5, 	MSG.RNDR_PROV_ZIP DESC\n" + 
				"";
		createAndWriteFile(path, tempData);
	}
}
