package com.carefirst.fep.filedrop;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * @author Uthaya Kumar Ravichandran
 * Date: 03/27/2019
 * Purpose: Modify the file dcn and file creation methods are available. This is used before file drop
 */
public class FileDropUtil {
	private Properties prop;
	File dcnFile;
	File wmDcnFile;
	String dcns = "";
	String wmDcns = "";

	public void loadProperties() {
		String env = System.getProperty("env");
		prop = new Properties();

		InputStream in = this.getClass().getClassLoader().getResourceAsStream(env + ".properties");
		try {
			prop.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public String getValue(String str) {
		return prop.getProperty(str);
	}

	public void createNewDCNFile(String dcnFileName) throws IOException {
		/*
		 * This method creates new dcn files.
		 * If there is wellmark claims available it will place the files in a different file. This is done to delete the wellmark claims on the same day of file drop
		 */
		if (dcnFileName.contains("_WM")) {
			wmDcnFile = new File(dcnFileName);
			wmDcnFile.createNewFile();

		} else {
			dcnFile = new File(dcnFileName);
			dcnFile.createNewFile();
		}
	}

	public void FileModification(String folderName) {
		/*
		 * This method will scan the folder for the files, retrieve the dcn, modify it and update the file with new dcn
		 */
		File parentFolder = new File(folderName);
		File[] folders = parentFolder.listFiles();

		for (File folder : folders) {
			File[] files = folder.listFiles();
			//Scanning folders and identifying files
			String content = null;
			for (File file : files) {
				System.out.println("Working on File:" + file.getName());
				Scanner scnr = null;
				try {
					scnr = new Scanner(new BufferedReader(new FileReader(file)));
					//Remove unwanted characters
					content = scnr.useDelimiter("\\Z").next();
					content = content.replaceAll("[^\\p{ASCII}]", "");
					//Calls the modify method to modify the dcn and BHT segment
					content = modifyContent(content);

					File outFile = new File(file.getAbsolutePath());
					//Write new content into file and new dcns into the file
					writeFile(outFile, content);
					writeFile(dcnFile, dcns);
					if(wmDcnFile!=null)
						writeFile(wmDcnFile, wmDcns);

				} catch (FileNotFoundException e) {
					System.out.println("File not Found" + file.getName());
				} finally {
					scnr.close();
				}

			}
		}
	}

	private void writeFile(File outFile, String content) {
		/*
		 * Method to create an empty file and write the content
		 */
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(outFile));
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private String modifyContent(String content) {
		/*
		 * Method to update BHT segment and DCN segment
		 */
		Pattern dcnPattern, bhtPattern;
		String strDCNPattern = "transID>(.*?)<", strBHTPattern = "BHT\\*0019\\*(.*?)\\*(.*?)\\*";
		Matcher dcnMatcher, bhtMatcher;
		String oldDCN, newDCN, oldBHT, newBHT;

		try {
			//Identify the old dcn and create a new DCN
			dcnPattern = Pattern.compile(strDCNPattern);
			dcnMatcher = dcnPattern.matcher(content);
			dcnMatcher.find();
			oldDCN = dcnMatcher.group(0);
			oldDCN = oldDCN.substring(8, oldDCN.length() - 1);
			newDCN = getNewDCN(oldDCN);
			dcns = dcns + newDCN + "\n";
		} catch (IllegalStateException e) {
			// Added for Lpp claims
			//LPP claims doesn't have the trans ID segment, so we are using ref* F8 segment to retrieve the DCN
			dcnPattern = Pattern.compile("REF\\*F8\\*(.*)~");
			dcnMatcher = dcnPattern.matcher(content);
			dcnMatcher.find();
			oldDCN = dcnMatcher.group(0);// .replace("REF*F8*","").replaceAll("~", "");
			oldDCN = oldDCN.substring(7, oldDCN.indexOf("~"));
			newDCN = getNewDCN(oldDCN);
			dcns = dcns + newDCN + "\n";
		}
		
		System.out.println("Modifying the old DCN " + oldDCN + " with new DCN " + newDCN);
		
		if(wmDcnFile!=null) {
			if (newDCN.endsWith("WM"))
				wmDcns = wmDcns + newDCN + "\n";
		}
		// Identify Old BHT and generate new BHT
		bhtPattern = Pattern.compile(strBHTPattern);
		bhtMatcher = bhtPattern.matcher(content);
		bhtMatcher.find();
		oldBHT = bhtMatcher.group(0);
		oldBHT = oldBHT.substring(12, oldBHT.length() - 1);
		newBHT = getNewBHT();

		//replace DCN and BHT segment
		content = content.replace(oldDCN, newDCN);
		content = content.replace(oldBHT, newBHT);

		return content;
	}

	private String getNewBHT() {
		return randomDataGen(15);
	}

	private String randomDataGen(int length) {
		/*
		 * Method to generate random digit for dcn and bht generation
		 */
		char[] values = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
				'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

		String out = "";
		for (int i = 0; i < length; i++) {
			out += values[(int) (java.lang.Math.random() * (values.length))];
		}
		return out;
	}

	private String getNewDCN(String oldDCN) {

		// Retrieve random digits and trailer from dcn
		String[] dgtTrlr = identifyDigitAndTrailer(oldDCN);

		String midDCN = randomDataGen(Integer.parseInt(dgtTrlr[0]));
		String first3 = oldDCN.substring(0, 3);
		String fourth = String.valueOf((int) (java.lang.Math.random() * 10));
		String fifth = oldDCN.substring(4, 5);
		String sixth = String.valueOf((int) (java.lang.Math.random() * 10));
		String first6 = first3 + fourth + fifth + sixth;
		return first6 + midDCN + dgtTrlr[1];

	}

	private String[] identifyDigitAndTrailer(String dcn) {
		/*
		 * Identify the plan based on the dcn trailer
		 */
		String[] trlr = new String[2];

		String rightDigit = dcn.substring(dcn.length() - 2);

		if (rightDigit.equals("PM")) {
			trlr[1] = "PM";
			trlr[0] = "4";
		} else if (rightDigit.equals("WM")) {
			trlr[1] = "WM";
			trlr[0] = "3";
		} else if (rightDigit.equals("CB") || rightDigit.equals("CF")) {
			//Old cambia claims are named with CF so we are using both CB and CF.
			trlr[1] = "CB";
			trlr[0] = "4";
		} else if (rightDigit.equals("NC")) {
			trlr[1] = "NC";
			trlr[0] = "4";
		} else if (rightDigit.equals("NE")) {
			trlr[1] = "NE";
			trlr[0] = "4";
		} else {
			trlr[1] = "P";
			trlr[0] = "4";
		}

		return trlr;
	}

}
