package com.carefirst.fep.filedrop;

public interface Constants {

	public static final String HOST_KEY = ".bootstrap.host";
	public static final String PORT_KEY = ".bootstrap.port";
	public static final String PORT_SEPARATOR = ":";
	public static final String DOT_SEPARATOR = ".";


	public static String SIT_ENV_NAME = "sit";
	public static String PDEV_ENV_NAME = "pdev";
	public static String UAT_ENV_NAME = "uat";
	public static String E2E_ENV_NAME = "e2e";
	public static String EUAT_ENV_NAME = "euat";
	public static String TT_ENV_NAME = "tt";
	public static String OCT_ENV_NAME = "oct";

	public static String PRE_ADJ_APP = "pre";
	public static String POST_ADJ_APP = "post";
	public static String MTGW_ADJ_APP = "mtgw";
}
