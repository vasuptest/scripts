package com.carefirst.fep.regression;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.filedrop.BridgeSender;
import com.carefirst.fep.filedrop.Constants;
import com.carefirst.fep.filedrop.FileDropUtil;
/**
 * @author Uthaya Kumar Ravichandran
 * Date: 03/27/2019
 * Purpose: To create the folders needed for regression Testing
 */
public class Reg02_FileDrop extends FileDropUtil implements FileFilter {

	@BeforeClass
	public void load() {
		loadProperties();
	}

	@Test(enabled = true)
	public void TC001_Modification() throws IOException {
		/* This method is to modify the DCN and bht segment in the EDI File
		 * It also places the new dcns in a separate file 
		 */
		createNewDCNFile(getValue("reg_fl_new_DCN"));

		String folderName = getValue("reg_EDI_Mdcl_fldr");
		FileModification(folderName);
	}
	
	@Test(enabled = true, dependsOnMethods="TC001_Modification") 
	public void TC001_FileDrop() {
		/* This method reads the parent folder and identifies the child folders
		 * Based on the name of the child folder name it drops all files in the corresponding queue
		 */
		String folderName = getValue("reg_EDI_Mdcl_fldr");
		File dir = new File(folderName);
		File[] files = dir.listFiles();
		if (files != null) {
			for (File file : files) {
				String srcDir = folderName + file.getName();
				if (file.getName().matches("CAREFIRST")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/GatewayRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("CAMBIA")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayCambiaRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("NORTHCAROLINA")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayNCRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("PREMERA")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayPMRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("WELLMARK")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayWMRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("NEBRASKA")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayNERequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("CAREFIRST-LPP")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("CAMBIA-LPP")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocCambiaLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("NORTHCAROLINA-LPP")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocNCLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("PREMERA-LPP")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocPMLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("WELLMARK-LPP")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocWMLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("NEBRASKA-LPP")) {
					BridgeSender in = new BridgeSender(Constants.UAT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocNELppRequestQueue");
					in.sendFromDir(srcDir);
				}
			}
		} else {
			System.out.println("No Subdirectory Found.");
		}
	}

	public boolean accept(File file) {
		return file.isDirectory();
	}

}
