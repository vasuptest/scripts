package com.carefirst.fep.filedrop;

import java.net.URL;
import java.net.URLClassLoader;

public class PrintClassPath {
	public static void main(String args[]){

		StringBuilder classPath = new StringBuilder("Class path: \n");
		ClassLoader sysClassLoader = ClassLoader.getSystemClassLoader();
		URL[] urls = ((URLClassLoader)sysClassLoader).getURLs();
		for(int i=0; i< urls.length; i++){
//			just silencing this, pls uncomment when ready
//			classPath.append(urls[i].getFile()).append("\n");
		}
		System.out.println(classPath.toString());
	}
}
