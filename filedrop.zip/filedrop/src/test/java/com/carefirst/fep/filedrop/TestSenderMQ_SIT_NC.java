package com.carefirst.fep.filedrop;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.filedrop.BridgeSender;
import com.carefirst.fep.filedrop.Constants;;

public class TestSenderMQ_SIT_NC implements FileFilter {
	private Properties prop;
	
	@BeforeClass
	public void loadProperties() {
		String env = System.getProperty("env");
		prop = new Properties();
		
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(env + ".properties");
		try {
			prop.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void test() {
		//folderName = "C:\\Users\\aac8154\\Desktop\\temp\\"
		String folderName = getValue("ncFolderName");
		File dir = new File(folderName);
		File[] files = dir.listFiles(new TestSenderMQ_SIT_NC());
		if (files != null) {
			for (File file : files) {
				String srcDir = folderName + file.getName();

				if (file.getName().matches("01_UcmtNC")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayNCRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("02_LPP")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("03_ClaimContext")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/ClaimContextRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("04_DCS")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/DcsRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("05_Provider")) {;
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/ProviderRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("06_Auth")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/AuthRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("07_MedicalPolicy")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/NCMPRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("08_Pricer")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/NCPricerRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("09_Packaging")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/PackagingRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("10_FEPOCReq")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/OcPackagingRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("11_ADJRESPONSE")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.POST_ADJ_APP,
							"jms/FepocReplyToQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("12_Split")) {
					BridgeSender in = new BridgeSender(Constants.SIT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/ClaimSplitRequestQueue");
					in.sendFromDir(srcDir);
				}
			}
		} else {
			System.out.println("No Subdirectory Found.");
		}
	}

	private String getValue(String str) {
		return prop.getProperty(str);
	}

	public boolean accept(File file) {
		return file.isDirectory();
	}

}
