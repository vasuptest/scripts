package com.carefirst.fep.filedrop;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.joda.time.DateTime;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Generic file manipulation methods.
 * Please do NOT include any logging in these methods.
 */
public class FepFileUtil_Archive {
	public static final String SystemPropertyForConfigurationDirectoryRoot = "fep.thin.config.root";

	private FepFileUtil_Archive() {
	}

//	public static byte[] getBinaryFileContents(final String file)
//			throws IOException {
//		File f = new File(file);
//		return getBinaryFileContents(f);
//	}
//
//	public static byte[] getBinaryFileContents(final File file)
//			throws IOException {
//		byte[] result = null;
//		FileInputStream fstream = null;
//		try {
//			fstream = new FileInputStream(file);
//			DataInputStream in = new DataInputStream(fstream);
//			byte[] buf = new byte[1024];
//			ByteArrayOutputStream bao = new ByteArrayOutputStream();
//			while (in.available() != 0) {
//				int numRead = in.read(buf);
//				if (numRead > 0) {
//					bao.write(buf, 0, numRead);
//				}
//			}
//			result = bao.toByteArray();
//		} finally {
//			if (null != fstream) {
//				fstream.close();
//			}
//		}
//		return result;
//	}
//
//	/**
//	 * Returns true if the passed in file path exists. Returns false otherwise
//	 * if the file doesn't exist or there is some exception encountered while
//	 * determining file existence. Should work with directories. Generally makes
//	 * sense to use absolution paths for this (but not a requirement).
//	 */
//	public static boolean fileExists(String filePath) {
//		File f = null;
//		boolean res = false;
//		try {
//			f = new File(filePath);
//			res = f.exists();
//		} catch (Exception e) {
//		}
//		f = null;
//		return (res);
//	}
//
	/**
	 * This method will attempt to make and return an InputStream for the given
	 * a name.
	 */
	public static InputStream makeInputStream(Class c, String name)
			throws IOException {
		File f;
		InputStream istream = null;

		try {
			f = new File(name);
			if (f.exists()) {
				istream = new FileInputStream(f);
			}
		} catch (Throwable e) {
			istream = null;
		}
		if (istream == null) {
			//
			// If we are here, then either couldn't file
			// input file as a 'normal' file object thing
			// or there was some exception with fetching it
			// so get lets try as a resource.
			try {
				ClassLoader cl = c.getClassLoader();
				istream = cl.getResourceAsStream(name);
			} catch (Throwable eee) {
				istream = null;
			}
		}
		if (istream == null) {
			// now the system class loader...
			istream = ClassLoader.getSystemResourceAsStream(name);
		}
		if (istream == null) {
			throw new IOException(
					"Couldn't locate resource or file with name [" + name + "]");
		}
		return (istream);
	}
//
//	public static InputStream makeInputStreamWithConfigRootSystemProperty(
//			Class c, String name) throws IOException {
//		File f;
//		InputStream istream = null;
//
//		try {
//			String configRootDirectory = System
//					.getProperty(SystemPropertyForConfigurationDirectoryRoot);
//			if (!FepStringUtil.isEmpty(configRootDirectory)) {
//				String userpathfname = configRootDirectory + File.separatorChar
//						+ name;
//				f = new File(userpathfname);
//				if (f.exists()) {
//					istream = new FileInputStream(f);
//				}
//			}
//			if (null == istream) {
//				f = new File(name);
//				if (f.exists()) {
//					istream = new FileInputStream(f);
//				}
//			}
//		} catch (Throwable e) {
//			istream = null;
//		}
//		if (istream == null) {
//			//
//			// If we are here, then either couldn't file
//			// input file as a 'normal' file object thing
//			// or there was some exception with fetching it
//			// so get lets try as a resource.
//			try {
//				ClassLoader cl = c.getClassLoader();
//				istream = cl.getResourceAsStream(name);
//			} catch (Throwable eee) {
//				istream = null;
//			}
//		}
//		if (istream == null) {
//			// now the system class loader...
//			istream = ClassLoader.getSystemResourceAsStream(name);
//		}
//		if (istream == null) {
//			throw new IOException(
//					"Couldn't locate resource or file with name [" + name + "]");
//		}
//		return (istream);
//	}
//
	/**
	 * Convenience method for invoking makeInputStream() with this class to be
	 * used as the passed 'client' class.
	 */
	public static InputStream makeInputStream(String name) throws IOException {
		return (FepFileUtil_Archive.makeInputStream(FepFileUtil_Archive.class, name));
	}

	public static Properties loadPropertiesFile(final String filename) {
		Properties result = null;
		if (!FepStringUtil.isEmpty(filename)) {
			InputStream is = null;
			try {
				is = makeInputStream(FepFileUtil_Archive.class, filename);
				if (null != is) {
					result = new Properties();
					result.load(is);
				}
			} catch (Exception e) {
				if (null != is) {
					try {
						is.close();
					} catch (Throwable t) {
					} // ignore
				}
				result = null;
			}
		}
		return result;
	}
//
//	public static Properties loadPropertiesFileWithConfigRootSystemProperty(
//			final String filename) throws Exception {
//		Properties result = null;
//		if (!FepStringUtil.isEmpty(filename)) {
//			InputStream is = null;
//			try {
//				is = makeInputStreamWithConfigRootSystemProperty(
//						FepFileUtil.class, filename);
//				if (null != is) {
//					result = new Properties();
//					result.load(is);
//				}
//			} finally {
//				if (null != is) {
//					try {
//						is.close();
//					} catch (Throwable t) {
//					} // ignore
//				}
//			}
//		}
//		return result;
//	}
//
	public static String getFileContents(String fileName) throws IOException {
		String result = null;
		InputStream fstream = null;
		try {
			fstream = makeInputStream(fileName);
			DataInputStream in = new DataInputStream(fstream);
			byte[] buf = new byte[1024];
			ByteArrayOutputStream bao = new ByteArrayOutputStream();
			while (in.available() != 0) {
				int numRead = in.read(buf);
				if (numRead > 0) {
					bao.write(buf, 0, numRead);
				}
			}
			result = bao.toString();
		} finally {
			if (null != fstream) {
				try {
					fstream.close();
				} catch (Exception e) {
				} // ignore
			}
		}
		return result;
	}
//
//	public static int getNumberOfLines(String fileName) throws IOException {
//		int numberOfLines = 0;
//
//		LineNumberReader lineCounter = null;
//		try {
//			lineCounter = new LineNumberReader(new FileReader(fileName));
//			while ((lineCounter.readLine()) != null) {
//				continue;
//			}
//			numberOfLines = lineCounter.getLineNumber();
//
//		} catch (IOException e) {
//			throw e;
//		}
//
//		return numberOfLines;
//	}
//
	public static void writeToFile(String filename, String contents) throws IOException {
		FileWriter writer = null;
		try {
			if (null == filename) {
				throw new IllegalArgumentException("Null filename sent to writeToFile method");
			}
			if (null == contents) {
				contents = "";
			}
			writer = new FileWriter(filename);
			writer.write(contents);
		}
		finally {
			if (null != writer) {
				writer.close();
			}
		}
	}

	public static void saveData(File destFolder, String fileFormat, String data){
		try{
//			File destFolder = new File(config.getProperty("destination.folder.name"));
//			File destFolder = new File(destination);
//			String format = "yyyy-MM-dd H-mm-sssss";
//			DateTime folderDateTime = new DateTime();
//
//			File destFolder = new File(rootEnvName+"-"+folderDateTime.toString(format));
//			destFolder.mkdirs();
//			File claimFile = new File(destFolder, Integer.toString( i) +config.getProperty("destination.file.name"));
			File claimFile = new File(destFolder, prepareFileName(data)+fileFormat);
			FileWriter writer = new FileWriter( claimFile );
			writer.write(data);
			writer.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	protected static String prepareFileName(String data){
		StringBuilder fileName = new StringBuilder();

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setNamespaceAware(true);
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(data)));
			doc.getDocumentElement().normalize();
			String rootElement = doc.getDocumentElement().getNodeName();

			NodeList nList = doc.getElementsByTagName(rootElement);

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					fileName.append(getTagValue("planCode", eElement));
					fileName.append("-").append(getTagValue("transID", eElement));
				}
			}
		} catch (Exception e) {
			System.out.println("Exception occuured while Trying to retrieve the TransId and PlanCode for the File Name" +
					" Saving the file with the timestamp instead.");
			DateTime dateTime = null;
			synchronized (dateTime){
				dateTime = new DateTime();
			}
			return Long.toString(dateTime.getMillis());
		}
		return fileName.toString();
	}
	protected static String getTagValue(String sTag, Element eElement) {
		NodeList nlList = eElement.getElementsByTagNameNS("*",sTag).item(0).getChildNodes();
		Node nValue = (Node) nlList.item(0);
		return nValue.getNodeValue();
	}

	public static Map<String, String> prepareData(String sourceDirName){
		Map<String, String> fileMap = new HashMap<String, String>();
		File sourceDir = new File(sourceDirName);
		if(sourceDir.isDirectory()){
//			String[] fileNames = sourceDir.list();
			File[] files = sourceDir.listFiles();
			for(int i=0;i<files.length; i++){
				try{
					String content = FepFileUtil_Archive.getFileContents(files[i].getAbsolutePath());
					fileMap.put(files[i].getName(), content);
				}catch(IOException ex){
					ex.printStackTrace();
				}
			}
		}
		return fileMap;
	}
}