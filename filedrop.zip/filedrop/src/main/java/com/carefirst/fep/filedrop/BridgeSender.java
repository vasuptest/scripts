package com.carefirst.fep.filedrop;

import java.util.Map;
import java.util.Properties;

import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

public class BridgeSender {
                public static final String DEFAULT_PROPS_FILE_NAME = "remoteConfig.properties";
                protected static final String DEFAULT_ENVIRONMENT = Constants.PDEV_ENV_NAME;
                protected static final String DEFAULT_APPLICATION = Constants.MTGW_ADJ_APP;
                protected QueueConnection connection = null;
                protected QueueSession session = null;
                protected MessageProducer producer = null;

                protected Properties config = null;
                protected String environmentName = "";
                protected String applicationName = "";

                public BridgeSender(){
                                config = FepFileUtil.loadPropertiesFile(DEFAULT_PROPS_FILE_NAME);
                                environmentName = DEFAULT_ENVIRONMENT;
                                applicationName = DEFAULT_APPLICATION;
                                //prepare();
                }
                public BridgeSender(String envName,String appName){
                                config = FepFileUtil.loadPropertiesFile(DEFAULT_PROPS_FILE_NAME);
                                environmentName = envName;
                                applicationName = appName;
                                //prepare();
                }

                public BridgeSender(String envName,String appName, String queuename){
                                config = FepFileUtil.loadPropertiesFile(DEFAULT_PROPS_FILE_NAME);
                                environmentName = envName;
                                applicationName = appName;
                                prepare(queuename);
                }
                /*protected void prepare(){
                                QueueConnectionFactory connectionFactory = null;
                                Properties env = new Properties();
                                env.put(Context.INITIAL_CONTEXT_FACTORY,"com.ibm.websphere.naming.WsnInitialContextFactory");
                                env.put("org.omg.CORBA.ORBClass", "com.ibm.CORBA.iiop.ORB");
                                StringBuilder address = new StringBuilder("corbaloc:iiop:");
                                address.append(config.getProperty(environmentName+Constants.HOST_KEY));
                                address.append(Constants.PORT_SEPARATOR);
                                String portkey = environmentName+Constants.DOT_SEPARATOR+applicationName+Constants.PORT_KEY;
                                address.append(config.getProperty(portkey));
                                env.put(Context.PROVIDER_URL,address.toString());
                                try{
                                                Context ctx = new InitialContext(env);
//                                            Object obj = ctx.lookup("jms/FeplFemsMqCF");
                                                Object obj = ctx.lookup(config.getProperty("connection.factory.name"));
                                                connectionFactory = (QueueConnectionFactory)obj;
                                                connection = connectionFactory.createQueueConnection();
                                                session = connection.createQueueSession(false,Session.AUTO_ACKNOWLEDGE);
                                                obj = ctx.lookup(config.getProperty("destination.queue.name"));
                                                //obj = ctx.lookup("jms/MTGatewayCambiaRequestQueue");
                                                Queue queue = (Queue) javax.rmi.PortableRemoteObject.narrow(obj, Queue.class);
                                                System.out.println(" Queue name:"+queue.getQueueName());
                                                producer = session.createProducer(queue);
                                }catch(Exception e){
                                                e.printStackTrace();
                                }

                }*/
                protected void prepare(String queuename){
                                QueueConnectionFactory connectionFactory = null;
                                Properties env = new Properties();
                                env.put(Context.INITIAL_CONTEXT_FACTORY,"com.ibm.websphere.naming.WsnInitialContextFactory");
                                env.put("org.omg.CORBA.ORBClass", "com.ibm.CORBA.iiop.ORB");
                                StringBuilder address = new StringBuilder("corbaloc:iiop:");
                                address.append(config.getProperty(environmentName+Constants.HOST_KEY));
                                address.append(Constants.PORT_SEPARATOR);
                                String portkey = environmentName+Constants.DOT_SEPARATOR+applicationName+Constants.PORT_KEY;
                                address.append(config.getProperty(portkey));
                                env.put(Context.PROVIDER_URL,address.toString());
                                try{
                                                Context ctx = new InitialContext(env);
                                                //Object obj = ctx.lookup("jms/FeplFemsMqCF");
                                                Object obj = ctx.lookup(config.getProperty("connection.factory.name"));
                                                connectionFactory = (QueueConnectionFactory)obj;
                                                connection = connectionFactory.createQueueConnection();
                                                session = connection.createQueueSession(false,Session.AUTO_ACKNOWLEDGE);
                                                //obj = ctx.lookup(config.getProperty("destination.queue.name"));
                                                obj = ctx.lookup(queuename);
                                                Queue queue = (Queue) javax.rmi.PortableRemoteObject.narrow(obj, Queue.class);
                                                System.out.println(" Queue name:"+queue.getQueueName());
                                                producer = session.createProducer(queue);
                                }catch(Exception e){
                                                e.printStackTrace();
                                }

                }

                public void sendFromDir(String srcDir) {
                                try {
//                                            obj = ctx.lookup("jms/FemsResponseQueue");
                                                Map<String,String> messages  = FepFileUtil.prepareData(srcDir);
                                                int i = 0;
                                                for(Map.Entry<String, String> entry: messages.entrySet()){
                                                                TextMessage message = session.createTextMessage(entry.getValue());
                                                                message.setJMSRedelivered(Boolean.FALSE);
                                                                try{
                                                                                producer.send(message);
                                                                                i++;
                                                                }catch(Exception e){
                                                                                System.out.println("Exception sending the message.");
                                                                }
                                                }
                                                System.out.println("total messages sent: "+i);
                                }catch (Exception e) {
                                                e.printStackTrace();
                                }finally{
                                                try{
                                                                if(connection != null){
                                                                                connection.stop();
                                                                                connection.close();
                                                                }if(session != null){
                                                                                session.close();
                                                                }
                                                }catch(JMSException ex){
                                                                ex.printStackTrace();
                                                }
                                }
                }

                public void sendMessage(String content){
                                try{
                                                TextMessage message = session.createTextMessage();
                                                message.setText(content);
                                                message.setJMSRedelivered(Boolean.FALSE);
                                                producer.send(message);
                                                System.out.println(message);
                                }catch(Exception ex){
                                                ex.printStackTrace();
                                }finally{
                                                try{
                                                                if(connection != null){
                                                                                connection.stop();
                                                                                connection.close();
                                                                }if(session != null){
                                                                                session.close();
                                                                }
                                                }catch(JMSException ex){
                                                                ex.printStackTrace();
                                                }
                                }

                }
}
