package com.carefirst.fep.regression;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.sql.DB_VerificationUtil;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
/**
 * @author Uthaya Kumar Ravichandran
 * Date: 03/27/2019
 * Purpose: To read data from new DB, Compare it with old DB data and display the results in Extent report
 */
public class Reg03_VerifyClaims extends DB_VerificationUtil {
	String reportURL;
	ExtentReports report;
	ExtentTest logger;

	String env = System.getProperty("env");

	@BeforeClass
	public void load() {
		loadProperties(env);
		reportURL = getValue("MedVrfyClmsRprt");
		report = new ExtentReports(reportURL);
	}

	@Test
	public void RetrieveData() {
		/*
		 * This method is executed after regression file drop
		 * After giving some time for the files to load, This method can be executed. So that it retrieves data from database after complete file load
		 * It reads the request files, retrieves the new dcn and file name(old dcn)
		 * It appends the newdcn to the filename and creates a file in verification folder of new DB
		 * It uses the new dcn retrieves the data from database and save it in the file created in previous step
		 * This creates the summary of claims and errored out claims
		 */
		logger = report.startTest("Summary - " + env);
		logger.assignAuthor("AutoTester");
		logger.assignCategory(env);
		String newDBFldrNm = getValue("newDBFldrNm");

		Connection e = connect();
		try {
			String vrfcnFldr = getValue("reg_DB_Mdcl_fldr");
			File prntFldr = new File(getValue("reg_EDI_Mdcl_fldr"));
			File[] chldFldrs = prntFldr.listFiles();
			for(File chldFldr: chldFldrs) {
				File[] files = chldFldr.listFiles();

				int totClaims = 0 , totErrors = 0;
				String errDCNs = "", temp = "";
				for(File file:files) {
					String dcn = readDCN(file.getAbsolutePath());
					System.out.println("Working on the DCN: " + dcn + "...");
					
					String vrfyFilePath = vrfcnFldr + "/" +  file.getParentFile().getName() + newDBFldrNm;
					String vrfyFileName = removeExtension(file.getName());
					extrctDBDataToFldr(e, vrfyFilePath, dcn + "_" + vrfyFileName + "_", dcn);
					totClaims++;
					
					if (rtrvErrVal(e, dcn)) {
						totErrors++;
						errDCNs = errDCNs + dcn + ", ";
					}
				}

				logger.log(LogStatus.PASS, "Total claims in " +  removeExtension(chldFldr.getName()) + ": " + totClaims);
				if (totErrors>0) {
					temp = "\nTotal Claims in Error Table : " + totErrors;
					temp = temp + "\nErrored out DCNs : " + errDCNs;

					logger.log(LogStatus.FAIL, temp);
				}
			}
			
		} catch (IOException ioex) {
			System.out.println("THERE IS A FILE EXCEPTION...");
			ioex.printStackTrace();
			logger.log(LogStatus.FAIL, ioex.toString());
		}
		
		
		
		report.endTest(logger);
	}


	@Test(dependsOnMethods = "RetrieveData")
	public void Compare() throws IOException {
		/*
		 * Reads the folders from new DB verification and old DB verification
		 * and triggers the comparison script on the folder level
		 */
		String vrfcnFldr = getValue("reg_DB_Mdcl_fldr");
		String oldDBFldrNm = getValue("oldDBFldrNm");
		String newDBFldrNm = getValue("newDBFldrNm");
		
		File prntFldr = new File(vrfcnFldr);
		File[] chldFldrs = prntFldr.listFiles();
		for(File chldFldr:chldFldrs) {

			logger = report.startTest(chldFldr.getName());
			logger.assignAuthor("AutoTester");
			logger.assignCategory(env);
			
			compareFldrs(logger, chldFldr + oldDBFldrNm, chldFldr + newDBFldrNm);

			report.endTest(logger);
		}

	}

	private String readDCN(String fileName) throws IOException {
		/*
		 * This method reads the whole content from the file
		 * In that content it separates the dcn and returns the dcn
		 */
		String ediCntnt = new String(Files.readAllBytes(Paths.get(fileName)), StandardCharsets.UTF_8).toUpperCase();

		ediCntnt = ediCntnt.replaceAll("[^\\p{ASCII}]", "");
		String dcn = ediCntnt.split("REF\\*F8\\*")[1].split("~")[0];
		return dcn;
	}

	@AfterClass
	public void runAfterClass() {
		report.endTest(logger);
		report.flush();
		report.close();
	}
}
