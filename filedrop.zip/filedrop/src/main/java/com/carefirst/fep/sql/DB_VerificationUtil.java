package com.carefirst.fep.sql;
/**
 * @author Uthaya Kumar Ravichandran
 * Date: 03/27/2019
 * Purpose: Retrieve the data using SQL and DCN from Database
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class DB_VerificationUtil extends VerificationUtil {
	private String extntRprtData;
	private ExtentTest logger;

	protected void extrctDBDataToFldr(Connection e, String fldrPath, String fileName, String dcn) {
		// Extract DB Field values for the checkpoints using the sql query mentioned in the file path "reg_rtrvQry_File"
		String rtrvSql = getValue("reg_rtrvQry_File");

		try {
			int qryCount = 0;
			BufferedReader br = new BufferedReader(new FileReader(rtrvSql));
			String query = "";
			try {
				while ((query = br.readLine()) != null) {
					// Use the DCN from the DCN file and execute the query to retrieve the data
					PreparedStatement ps = e.prepareStatement(query);
					ps.setString(1, dcn);

					ResultSet rs = ps.executeQuery();
					ResultSetMetaData metaData = rs.getMetaData();
					int colCount = metaData.getColumnCount();
					String tableName = "";

					// Retrieve Table Name
					try {
						tableName = query.toUpperCase().split("FROM ")[1].split(" WHERE")[0] + "\n";
					} catch (Exception ex) {
						tableName = "" + "\n";
						System.out.println("Not able to identify the table name...");
					}

					String tempData = tableName;

					// Retrieve Column names
					for (int col = 1; col <= colCount; col++)
						tempData = tempData + "| " + metaData.getColumnName(col);

					// Retrieve Data
					while (rs.next() == true) {
						tempData = tempData + "\n";
						for (int col = 1; col <= colCount; col++) {
							tempData = tempData + "| " + rs.getString(col);
						}
					}
					
					//Create separate file for each query in the query file and save the table data retrieved using DCN
					createAndWriteFile(fldrPath + fileName + (++qryCount) + ".txt", tempData);
					rs.close();
					ps.close();
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}

			br.close();
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	protected boolean rtrvErrVal(Connection e, String dcn) {
		String rtrvSql = getValue("reg_qry_Error");
		PreparedStatement ps;
		try {
			ps = e.prepareStatement(rtrvSql);
			ps.setString(1, dcn);

			ResultSet rs = ps.executeQuery();
			while (rs.next() == true) {
				return true;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return false;
	}
	
	protected void compareFldrs(ExtentTest tempLogger, String oldFilePath, String newFilePath) throws IOException {
		/* Identify the files available in Old DB folder
		 * Retrieve the new file corresponding to the old file.
		 * old file will be named using old file DCN
		 * new File will be name with both new and old DCN
		 * so the old file use its own file name to locate the new file
		 * Once it locates the new file corresponding to the old file, it simply passes the control to the file comparison method
		 */
		File[] oldFiles = new File(oldFilePath).listFiles();
		File[] newFiles = new File(newFilePath).listFiles();
		int count = 0;
		logger = tempLogger;

		//Update the heading for extent Report
		updateHeading();

		// To handle if the folder is empty -- NotInDB Folder
		if (new File(oldFilePath).exists())
			for (File oldFile : oldFiles) {
				File newFile = null;
				//Remove file extension and work with file name
				String oldFileName = removeExtension(oldFile.getName());
				newFile = idntfyMtchngFile(newFiles, count, oldFileName);

				if (newFile == null) {
					System.out.println("Matching file for the old File " + oldFileName + " is not found");

					logger.log(LogStatus.FAIL, "Matching file for the old File " + oldFileName + " is not found");
				} else {
					String newFileName = removeExtension(newFile.getName());
					compareFiles(oldFile, newFile, rtrvDCNFrmFlNm(oldFileName), rtrvDCNFrmFlNm(newFileName));

				}
				count++;
			}
	}

	private String rtrvDCNFrmFlNm(String fileName) {
		return fileName.split("_")[0];
	}

	private void compareFiles(File oldFile, File newFile, String oldDCN, String newDCN) throws IOException {
		/* Compare the records available in the old file and new file
		 * if it matches move to the next line in the file 
		 * if it doesnt' match then compare individual fields and locate the difference and place them in the extent report
		 * In each file, First line in the file corresponds to the Table name
		 * In each file, Second line in the file corresponds to the column names
		 * Starting from third line its all field values in each file 
		 */
		@SuppressWarnings("resource")
		BufferedReader readOldFile = new BufferedReader(new FileReader(oldFile));
		@SuppressWarnings("resource")
		BufferedReader readNewFile = new BufferedReader(new FileReader(newFile));
		String oldLine = "";
		String newLine = "";

		String tblDtls[] = rtrvDtlsFrmFile(readOldFile, readNewFile);

		while (oldLine != null || newLine !=null) {
			
			compareFields(oldLine, newLine, tblDtls[0], tblDtls[1], oldDCN, newDCN);
			
			oldLine = readOldFile.readLine();
			newLine = readNewFile.readLine();
		}
	}

	private void compareFields(String oldLine, String newLine, String tblNm, String tblClmns, String oldDCN,
			String newDCN) throws IOException {
		/*All field values are stored in a format separated by "|" symbol
		 * First all the values are seaprated by using split operation
		 * Each field value in old file is compared with the field value in new file
		 * and hte results are stored in extent report
		 */
		
		extntRprtData = "";
		
		if(oldLine==null || newLine==null)
			updateTableData(oldDCN, newDCN, tblNm, tblClmns, oldLine, newLine);
		else if (!oldLine.equals(newLine)) {
			String[] colName = tblClmns.split("\\| ");
			String[] oldFldValue = splitString(oldLine, "\\| ", colName.length);// oldLine.split("\\| ");
			String[] newFldValue = splitString(newLine, "\\| ", colName.length); // newLine.split("\\| ");

			int colCount = colName.length;
			for (int i = 0; i < colCount; i++) {
				if (!oldFldValue[i].equals(newFldValue[i]) ) {

					if (oldFldValue[i].equals("EMPTY") || newFldValue[i].equals("EMPTY")) {
						updateTableData(oldDCN, newDCN, tblNm, tblClmns, oldLine, newLine);
						i=colCount;
					} else {
						updateTableData(oldDCN, newDCN, tblNm, colName[i], oldFldValue[i], newFldValue[i]);
					}
				}
			}
		}
		
		if (!extntRprtData.equals("")) {
			logger.log(LogStatus.FAIL, extntRprtData);
		}
	}

	private String[] splitString(String strLn, String spltVal, int Cnt) {
		/*Separate the values using a separator spltVal.
		 * If the field values are not available then fill the field values with EMPTY.
		 * IF the field values are available store it an array and return it
		 */
		String[] splitString;
		if (strLn != null && !strLn.equals("")) {
			splitString = strLn.split(spltVal);
		} else {
			splitString = new String[Cnt];
			for (int i = 0; i < Cnt; i++)
				splitString[i] = "EMPTY";
		}

		return splitString;
	}

	private String[] rtrvDtlsFrmFile(BufferedReader readOldFile, BufferedReader readNewFile) throws IOException {
		// First line contains table name and the second line contains column name
		String tblName;
		if ((tblName = readOldFile.readLine()) != null)
			readNewFile.readLine();

		String colName;
		if ((colName = readOldFile.readLine()) != null)
			readNewFile.readLine();

		String tblDtls[] = { tblName, colName };

		return tblDtls;
	}

	private File idntfyMtchngFile(File[] newFiles, int flPstn, String oldFileNm) {
		/*This method is for identifying the matching file in new DB
		 * 
		 */
		if (newFiles[flPstn].getName().contains("_" + oldFileNm)) {
			System.out.println(
					"Identified the new File " + newFiles[flPstn] + " which is matching with old file " + oldFileNm);
			return newFiles[flPstn];
		} else
			for (File file : newFiles)
				if (file.getName().contains("_" + oldFileNm)) {
					System.out.println("Identified the new File " + newFiles[flPstn]
							+ "which is matching with old file " + oldFileNm);
					return file;
				}

		System.out.println("File match not found for the file" + oldFileNm);
		return null;
	}

	public String removeExtension(String str) {
		//This is for removing the file extension
		if (str == null)
			return null;
		// Get position of last '.'.

		int pos = str.lastIndexOf(".");
		// If there wasn't any '.' just return the string as is.

		if (pos == -1)
			return str;
		return str.substring(0, pos);
	}

	protected void createAndWriteFile(String path, String tempData) {
		/*This method is used to create text files with data
		 * It might be a request file or the verification file
		 */
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File(path)));
			bw.write(tempData);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/*Below Methods are for updating extent report	 
	 * Extent Report Tabs are based on the Folder Structure
	 * Each folder will be considered as a Tab
	 * Discrepancies in the table will be displayed in the report
	 */
	private void updateTableData(String oldDCN, String newDCN, String tblNm, String colNm, String expVal,
			String actVal) {
		extntRprtData = updateTblHdr();
		extntRprtData = extntRprtData + "<tr><td>" + oldDCN + "</td><td>" + newDCN + "</td><td>" + tblNm + "/" + colNm
				+ "</td><td>" + expVal + "</td><td>" + actVal + "</td></tr>";
		extntRprtData = extntRprtData + updateTableFooter();
		System.out.println(oldDCN + "| " + newDCN + "| " + tblNm + "/" + colNm + "| " + expVal + "| " + actVal);

	}

	private void updateHeading() {
		//This method is for creating the extent report table headers
		String tblHdr = updateTblHdr();
		tblHdr = tblHdr
				+ "<tr><b><td>Old DCN</td><td>New DCN</td><td>Table/Col Name</td><td>Expected Value</td><td>Actual Value</td></b></tr>";
		tblHdr = tblHdr + updateTableFooter();

		logger.log(LogStatus.INFO, tblHdr);
	}

	private String updateTblHdr() {
		//This method is for spacing the table columns in extent report properly
		return "<table style=\"width:100%\"><col width=\"10%\"><col width=\"10%\"><col width=\"20%\"><col width=\"20%\"><col width=\"20%\">";
	}

	private String updateTableFooter() {
		return "</table>";
	}

}
