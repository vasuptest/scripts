package com.carefirst.fep.filedrop;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.filedrop.BridgeSender;
import com.carefirst.fep.filedrop.Constants;

public class SmokeTest_TT extends FileDropUtil implements FileFilter {

	@BeforeClass
	public void load() throws IOException {
		loadProperties();
		// createNewDCNFile(getValue("claimSmokeDCNFile"));
	}

	@Test(enabled = true)
	public void TC001_Modification() throws IOException {

		createNewDCNFile(getValue("claimSmokeDCNFile"));

		String folderName = getValue("medFolderName");
		FileModification(folderName);
	}
	
	@Test(enabled = true, dependsOnMethods="TC001_Modification") // 
	public void TC001_FileDrop() {
		String folderName = getValue("medFolderName");
		File dir = new File(folderName);
		File[] files = dir.listFiles();
		if (files != null) {
			for (File file : files) {
				String srcDir = folderName + file.getName();
				if (file.getName().matches("01-UCCF")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/GatewayRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("02-UCMT")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayCambiaRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("03-QMTNC")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayNCRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("04-QMTPM")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayPMRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("05-QMTWL")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayWMRequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("06-QMTNE")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.MTGW_ADJ_APP,
							"jms/MTGatewayNERequestQueue");
					in.sendFromDir(srcDir);
					System.out.println(srcDir);
				} else if (file.getName().matches("07-LPPCF")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("08-LPPCB")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocCambiaLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("09_LPPNC")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocNCLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("10_LPPPM")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocPMLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("11_LPPWM")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocWMLppRequestQueue");
					in.sendFromDir(srcDir);
				} else if (file.getName().matches("12_LPPNE")) {
					BridgeSender in = new BridgeSender(Constants.TT_ENV_NAME, Constants.PRE_ADJ_APP,
							"jms/FepocNELppRequestQueue");
					in.sendFromDir(srcDir);
				}
			}
		} else {
			System.out.println("No Subdirectory Found.");
		}
	}

	public boolean accept(File file) {
		return file.isDirectory();
	}

}
