package com.carefirst.fep.regression;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.sql.DB_VerificationUtil;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
/**
 * @author Uthaya Kumar Ravichandran
 * Date: 03/27/2019
 * Purpose: Get connection details like DB, user credentials and file containing dcn from the user. 
 * Retrieves data from the database and store it a text file
 */
public class Reg01_RetrieveFiles extends DB_VerificationUtil{
	String reportURL;
	ExtentReports report;
	ExtentTest logger;

	private static Connection conn;
	/*
	 * Retrieves environment, user credentials from jenkins
	 */
	String env = System.getProperty("env");
	String USR_NM = System.getenv("USER_ID");
	String USR_PWD = System.getenv("USER_PASSWORD");
	String ENVIRONMENT = System.getenv("ENVIRONMENT");
		
	@BeforeClass
	public void load() {
		loadProperties(env);
		reportURL = getValue("MedRtrvFilesRprt");
		report = new ExtentReports(reportURL);
	}

	@Test
	public void RetrieveData() {
		/*
		 * Reads dcn file, retrieves the data from db for the dcn and store it in text file
		 */
		String dcnFile = getValue("reg_fl_old_DCN");
		String dcn = null, fldrNm = null;
		logger = report.startTest("Reg Test - Retrieve Data - " + env);
		logger.assignAuthor("AutoTester");
		logger.assignCategory(env);

		Connection e = connect();
		String reqQuery = getValue("reg_qry_request");
		String xmlPath = getValue("reg_EDI_Mdcl_fldr");
		String vrfcnPath = getValue("reg_DB_Mdcl_fldr");
		String oldDBFldrNm = getValue("oldDBFldrNm");
		
		try {
			BufferedReader readDCNFile = new BufferedReader(new FileReader(dcnFile));
			clearFolders(new File(xmlPath));
			clearFolders(new File(vrfcnPath));

			while (((dcn = readDCNFile.readLine()) != null)) {
				try {
					// code to retrieve data from DB
					PreparedStatement reqPS = e.prepareStatement(reqQuery);
					reqPS.setString(1, dcn);
					ResultSet reqRS = reqPS.executeQuery();

					System.out.println("Retrieving Data for the DCN : " + dcn + "....");
					if (reqRS.next() == true) {
						fldrNm = retrieveFldrNm(reqRS.getString(2), reqRS.getString(3));
						
						// PLace xml files in corresponding location
						createTextFile(xmlPath + fldrNm + "/" + dcn + ".txt", reqRS.getString(1));
						extrctDBDataToFldr(e, vrfcnPath + fldrNm + oldDBFldrNm, dcn + "_", dcn);
						
						logger.log(LogStatus.PASS, "Extracted the DB Details and xml request for the DCN: " + dcn);
					} else {
						// place an empty file with dcn as file name if not available in db
						createTextFile(xmlPath + "/NotInDB/" + dcn + ".txt", "");
						createTextFile(vrfcnPath + "/NotInDB/" + dcn + ".txt", "");
						System.out.println("******* DCN " + dcn + " is not available in DB!!!");
						logger.log(LogStatus.FAIL, "DCN " + dcn + " is not available in DB!");
					}
					reqRS.close();
					reqPS.close();
				} catch (SQLException sqlex) {
					System.out.println("THERE IS A SQL EXCEPTION....");
					sqlex.printStackTrace();
				}
			}
			readDCNFile.close();
			
		} catch (IOException ioex) {
			System.out.println("THERE IS A FILE EXCEPTION...");
			ioex.printStackTrace();
		}
	}

	

	private void clearFolders(File xmlPath) {
		/*
		 * Recursive function to delete all files inside each folder
		 */
		File[] files = xmlPath.listFiles();
		for (File file : files) {
			if (file.isDirectory())
				clearFolders(file);
			else
				file.delete();
		}

	}

	private String retrieveFldrNm(String modlNm, String orgId) {
		/*
		 * Based on the plan org, this method returns the folder name where the claim need to be placed
		 */
		if (modlNm.equals("CGWForwarder"))
			return "/CAREFIRST/";
		else if (modlNm.equals("MTFWCB"))
			return "/CAMBIA/";
		else if (modlNm.equals("MTFWNC"))
			return "/NORTHCAROLINA/";
		else if (modlNm.equals("MTFWPM"))
			return "/PREMERA/";
		else if (modlNm.equals("MTFWWM"))
			return "/WELLMARK/";
		else if (modlNm.equals("MTFWNE"))
			return "/NEBRASKA/";
		else {
			if (orgId.equals("CAREFIRST"))
				return "/CAREFIRST-LPP/";
			else if (orgId.equals("CAMBIA"))
				return "/CAMBIA-LPP/";
			else if (orgId.equals("BCBSNC"))
				return "/NORTHCAROLINA-LPP/";
			else if (orgId.equals("PREMERA"))
				return "/PREMERA-LPP/";
			else if (orgId.equals("WELLMARK"))
				return "/WELLMARK-LPP/";
			else if (orgId.equals("BCBSNE"))
				return "/NEBRASKA-LPP/";
			else
				return "/NotInDB/";
		}
	}

	private void createTextFile(String xmlPath, String xmlReq) {
		/*
		 * Create a text, write the content and close file.
		 */
		try {
			Writer writer = null;
			new File(xmlPath).createNewFile();
			writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(xmlPath)));
			writer.write(xmlReq);
			writer.close();
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	protected Connection connect() {
		/*
		 * Connect to Database using connection string and user credentials
		 */
		String environment = getValue(ENVIRONMENT + "_environment");

		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(environment, USR_NM, USR_PWD);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	@AfterClass
	public void runAfterClass() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		report.endTest(logger);
		report.flush();
		report.close();
	}
}
