package com.carefirst.fep.verification;

import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.sql.VerificationUtil;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class SmokeTest_Verification extends VerificationUtil{
	String reportURL;
	ExtentReports report;
	ExtentTest logger;

	String env = System.getProperty("env");
	
	@BeforeClass
	public void load() {
		loadProperties(env);
		reportURL = getValue("claimSmokeVerificationRprt");
		report = new ExtentReports(reportURL);
	}
	
	@Test
	public void VerifyClaims() {
		String dcnFile = getValue("claimSmokeDCNFile");
		logger = report.startTest("Smoke Test - " + env);
		logger.assignAuthor("AutoTester");
		logger.assignCategory(env);
		
		try {
			boolean status = VerifyClaims(logger, dcnFile, "qvResFEPOCQuery", "jenkinsWorkspace");
			if (status == false)
				org.testng.Assert.fail("Please check the Report for Failure");
			
		} catch (IOException e) {
			System.out.println("THERE IS A FILE EXCEPTION...");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("THERE IS A SQL EXCEPTION....");
			e.printStackTrace();
		}
		
	}
	
	@AfterClass
	public void runAfterClass() {
		report.endTest(logger);
		report.flush();
		report.close();
	}
	
}
