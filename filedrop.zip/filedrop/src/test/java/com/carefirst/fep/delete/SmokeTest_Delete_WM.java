package com.carefirst.fep.delete;

import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.sql.DeleteUtil;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class SmokeTest_Delete_WM extends DeleteUtil {
	String reportURL;
	ExtentReports report;
	ExtentTest logger;

	String env = System.getProperty("env");

	@BeforeClass
	public void load() {
		loadProperties(env);
		reportURL = getValue("claimSmokeDeleteRprt_WM");
		report = new ExtentReports(reportURL);
	}

	@Test
	public void deleteClaims() {
		String dcnFile = getValue("claimSmokeDcnWMFile");
		String deleteSQLFile = getValue("claimDeleteSQL");
		logger = report.startTest("Smoke Test - " + env);
		logger.assignAuthor("AutoTester");
		logger.assignCategory(env);

		try {
			runDelete(dcnFile, deleteSQLFile, logger);
		} catch (IOException e) {
			System.out.println("THERE IS A FILE EXCEPTION...");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("THERE IS A SQL EXCEPTION....");
			e.printStackTrace();
		}
	}

	@AfterClass
	public void runAfterClass() {
		report.endTest(logger);
		report.flush();
		report.close();
	}
}
