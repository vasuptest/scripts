package com.carefirst.fep.sql;

/**
 * @author Uthaya Kumar Ravichandran
 * Date: 01/15/2019
 * Purpose: Delete dcns from the database
 */
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class DeleteUtil {

	private static Connection conn;
	private Properties prop;

	public void loadProperties(String env) {
		prop = new Properties();

		InputStream in = this.getClass().getClassLoader().getResourceAsStream(env + ".properties");
		try {
			prop.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getValue(String str) {
		return prop.getProperty(str);
	}

	protected void runDelete(String dcnfile, String deletefile, ExtentTest logger)
			throws FileNotFoundException, IOException, SQLException {
		/*
		 * Use the sql query file and dcn file to delete the dcn in all tables 
		 */
		Connection e = connect();

		@SuppressWarnings("resource")
		BufferedReader readFiledcn = new BufferedReader(new FileReader(dcnfile));

		String dcn = "";
		while ((dcn = readFiledcn.readLine()) != null) {
			dcn = dcn.replaceAll(" ", "");
			logger.log(LogStatus.PASS, "Deleting Claim : " + dcn);
			System.out.println("Deleting Claim: " + dcn);

			@SuppressWarnings("resource")
			BufferedReader readFiledelete = new BufferedReader(new FileReader(deletefile));

			String query = "";
			while ((query = readFiledelete.readLine()) != null) {
				PreparedStatement s = e.prepareStatement(query);

				s.setString(1, dcn);
				System.out.println(query);

				s.executeQuery();
				s.close();
			}
		}
		e.commit();
		e.close();
	}

	private Connection connect() {
		/*
		 * This is to connect to the Database using the oracle driver, connection string,
		 * user credentials and encrypted password This is generic to all environments
		 */
		String dPassword = null;
		String username = getValue("username");
		String encryptedPassword = getValue("encryptedPassword");
		ProtectedPwdFile eCypher = new ProtectedPwdFile();

		try {
			dPassword = eCypher.decrypt(encryptedPassword);
		} catch (GeneralSecurityException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String environment = getValue("environment");

		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection(environment, username, dPassword);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

}
