package com.carefirst.fep.on.demand.filedrop;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.carefirst.fep.filedrop.BridgeSender;
import com.carefirst.fep.filedrop.Constants;
import com.carefirst.fep.filedrop.FileDropUtil;
import com.carefirst.fep.filedrop.UnZip;

public class On_Demand_Filedrop extends FileDropUtil implements FileFilter {

	public static String loadTyp = System.getenv("SELECT LOAD TYPE");
	public static String env = System.getenv("ENVIRONMENT").toLowerCase();
	public static String component = System.getenv("COMPONENT");

	@BeforeClass
	public void load() throws IOException {
		loadProperties();
	}

	@Test(enabled = true)
	public void TC001_OnDemandFileDrop() {
		
		if (loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")) {
			String reqPyld = System.getenv("REQUEST PAYLOAD");
			msgDropQueue(reqPyld);
		} else {
			// Unzips the input provider file by the user.
			String inputFolder = getValue("inputFiles");
			String outputFolder = getValue("outputFiles");

			UnZip unZip = new UnZip();
			unZip.unZipIt(inputFolder, outputFolder);

			File dir = new File(outputFolder);
			File[] files = dir.listFiles();
			if (files != null) {
				for (File file : files) {
					String srcDir = outputFolder + file.getName();
					msgDropQueue(srcDir);
				}
			}
		}
	}

	public void msgDropQueue(String payLoadTyp){
		
		if (component.equals("CGWForwarder")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/GatewayRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("UCMT-CB")) {
			BridgeSender in = new BridgeSender(env, Constants.MTGW_ADJ_APP,
					"jms/MTGatewayCambiaRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("UCMT-NC")) {
			BridgeSender in = new BridgeSender(env, Constants.MTGW_ADJ_APP,
					"jms/MTGatewayNCRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("UCMT-PM")) {
			BridgeSender in = new BridgeSender(env, Constants.MTGW_ADJ_APP,
					"jms/MTGatewayPMRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("UCMT-WM")) {
			BridgeSender in = new BridgeSender(env, Constants.MTGW_ADJ_APP,
					"jms/MTGatewayWMRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("UCMT-NE")) {
			BridgeSender in = new BridgeSender(env, Constants.MTGW_ADJ_APP,
					"jms/MTGatewayNERequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("LPP-CF")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocLppRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("LPP-CB")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocCambiaLppRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("LPP-NC")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocNCLppRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("LPP-PM")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocPMLppRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("LPP-WM")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocWMLppRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		} else if (component.equals("LPP-NE")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocNELppRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("CLAIMCONTEXT")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/ClaimContextRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("DCS")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/DcsRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("PROVIDER")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/ProviderRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("AUTH")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/AuthRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("CUSTOM RULE EDIT")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/CustomRuleEditRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("SPLIT REQUEST")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/ClaimSplitRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("CFPricer")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/CareFirstPricerRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("CBPricer")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/CambiaPricerRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("NCPricer")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/NCPricerRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("PMPricer")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/PMPricerRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("WMPricer")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/WMPricerRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("NEPricer")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/NEPricerRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("CFMedicalPolicy")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/CareFirstMPRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("CBMedicalPolicy")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/CambiaMPRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("NCMedicalPolicy")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/NCMPRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("PMMedicalPolicy")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/PMMPRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("WMMedicalPolicy")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/WMMPRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("NEMedicalPolicy")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/NEMPRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("PACKAGING")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/PackagingRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOC")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/OcPackagingRequestQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOCRequest_NG")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/OcPackagingRequestNextGenQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOCRequestNG_CF")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocClaimRequestNextGenQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOCRequestNG_CB")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocCambiaClaimRequestNextGenQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOCRequestNG_NC")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocNCClaimRequestNextGenQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOCRequestNG_NE")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocNEClaimRequestNextGenQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOCRequestNG_PM")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocPMClaimRequestNextGenQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("FEPOCRequestNG_WM")) {
			BridgeSender in = new BridgeSender(env, Constants.PRE_ADJ_APP,
					"jms/FepocWMClaimRequestNextGenQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}else if (component.equals("ADJRESPONSE")) {
			BridgeSender in = new BridgeSender(env, Constants.POST_ADJ_APP,
					"jms/FepocReplyToQueue");
			if(loadTyp.equalsIgnoreCase("SINGLE REQUEST PAYLOAD")){
				in.sendMessage(payLoadTyp);
				System.out.println(payLoadTyp);
			}else{
				in.sendFromDir(payLoadTyp);
				System.out.println(payLoadTyp);
			}
		}
	
	}

	public boolean accept(File file) {
		return file.isDirectory();
	}

}
